"use strict";

const API_URL = "/api/food-waste";
const demoMode = new URLSearchParams(window.location.search).get("demo") === "1";
const demoStorageKey = "harvest-food-waste-demo";
const statuses = ["PENDING", "IN_PROCESS", "COMPLETED", "DISTRIBUTED"];
const safetyChecks = ["PENDING", "SAFE", "UNSAFE", "UNDER_REVIEW"];
const categoryLabels = {
  "fruit-vegetable": "Fruit & vegetables",
  "uneaten-food": "Uneaten food",
  "fresh-cooked": "Freshly cooked"
};
const statusLabels = {
  PENDING: "Pending",
  IN_PROCESS: "In progress",
  COMPLETED: "Completed",
  DISTRIBUTED: "Distributed"
};
const safetyLabels = {
  PENDING: "Pending",
  SAFE: "Safe",
  UNSAFE: "Unsafe",
  UNDER_REVIEW: "Under review"
};
const categoryIcons = {
  "fruit-vegetable": "✳",
  "uneaten-food": "◒",
  "fresh-cooked": "♨"
};

const elements = {
  rows: document.querySelector("#listing-rows"),
  empty: document.querySelector("#empty-state"),
  emptyTitle: document.querySelector("#empty-title"),
  emptyCopy: document.querySelector("#empty-copy"),
  total: document.querySelector("#stat-total"),
  pending: document.querySelector("#stat-pending"),
  progress: document.querySelector("#stat-progress"),
  distributed: document.querySelector("#stat-distributed"),
  count: document.querySelector("#heading-count"),
  navCount: document.querySelector("#nav-count"),
  summary: document.querySelector("#results-summary"),
  search: document.querySelector("#search-input"),
  status: document.querySelector("#status-filter"),
  category: document.querySelector("#category-filter"),
  dialog: document.querySelector("#create-dialog"),
  form: document.querySelector("#create-form"),
  formError: document.querySelector("#form-error"),
  submit: document.querySelector("#submit-listing"),
  toastRegion: document.querySelector("#toast-region"),
  aiSuggest: document.querySelector("#ai-suggest"),
  aiSuggestion: document.querySelector("#ai-suggestion"),
  organizationList: document.querySelector("#organization-list"),
  organizationButton: document.querySelector("#load-organizations")
};

let listings = [];

function getDemoListings() {
  const saved = window.localStorage.getItem(demoStorageKey);
  if (saved !== null) {
    const parsed = JSON.parse(saved);
    if (!Array.isArray(parsed)) throw new Error("Saved demo listings have an invalid format.");
    return parsed;
  }

  const now = Date.now();
  const starterListings = [
    {
      id: 1,
      category: "fresh-cooked",
      description: "Roasted vegetable bowls",
      quantity: "8 portions",
      location: "Community Kitchen",
      status: "PENDING",
      safetyCheck: "PENDING",
      submittedAt: new Date(now - 1000 * 60 * 45).toISOString()
    },
    {
      id: 2,
      category: "fruit-vegetable",
      description: "Seasonal apples & pears",
      quantity: "1 crate",
      location: "Market Hall, Door 2",
      status: "IN_PROCESS",
      safetyCheck: "SAFE",
      submittedAt: new Date(now - 1000 * 60 * 60 * 5).toISOString()
    },
    {
      id: 3,
      category: "uneaten-food",
      description: "Fresh bread and rolls",
      quantity: "12 pieces",
      location: "North Street Café",
      status: "DISTRIBUTED",
      safetyCheck: "SAFE",
      submittedAt: new Date(now - 1000 * 60 * 60 * 24).toISOString()
    }
  ];
  window.localStorage.setItem(demoStorageKey, JSON.stringify(starterListings));
  return starterListings;
}

function demoRequest(path, options) {
  const method = options.method || "GET";
  if (path === "/organizations" && method === "GET") {
    throw new Error("Live Jaipur map search is available when Harvest runs with Spring Boot.");
  }
  if (path === "/ai/suggest" && method === "POST") {
    const request = JSON.parse(options.body);
    const description = request.description.toLocaleLowerCase();
    const category = /rice|meal|cooked|soup|bread|baked|prepared/.test(description)
      ? "fresh-cooked"
      : /fruit|vegetable|produce|apple|pear|tomato/.test(description)
        ? "fruit-vegetable"
        : request.category || "";
    return {
      category,
      quantity: request.quantity || "",
      nextSteps: [
        "Confirm the item count and pickup location.",
        "Add an appropriate collection time with the recipient."
      ],
      note: "Local demo helper only; not a live AI response. A person must verify all details and assess food safety."
    };
  }
  const match = path.match(/^\/(\d+)(?:\/(status|safety-check))?$/);
  if (!match && path !== "") throw new Error("That demo API route is not available.");

  let demoListings = getDemoListings();
  if (method === "GET" && path === "") return demoListings;

  if (method === "POST" && path === "") {
    const listing = {
      ...JSON.parse(options.body),
      id: demoListings.reduce((largest, item) => Math.max(largest, Number(item.id) || 0), 0) + 1,
      status: "PENDING",
      safetyCheck: "PENDING",
      submittedAt: new Date().toISOString()
    };
    demoListings.push(listing);
    window.localStorage.setItem(demoStorageKey, JSON.stringify(demoListings));
    return listing;
  }

  if (!match) throw new Error(`Unsupported demo API operation: ${method} ${path}`);
  const [, id, action] = match;
  const index = demoListings.findIndex((item) => String(item.id) === id);
  if (index < 0) throw new Error(`Food waste item ${id} was not found in this demo.`);

  if (method === "PUT" && action) {
    const update = JSON.parse(options.body);
    demoListings[index] = {
      ...demoListings[index],
      ...(action === "status" ? { status: update.status } : { safetyCheck: update.safetyCheck })
    };
    if (action === "status") {
      demoListings[index].processedAt =
        update.status === "COMPLETED" || update.status === "DISTRIBUTED"
          ? new Date().toISOString()
          : null;
    }
    window.localStorage.setItem(demoStorageKey, JSON.stringify(demoListings));
    return demoListings[index];
  }

  if (method === "DELETE" && !action) {
    demoListings = demoListings.filter((item) => String(item.id) !== id);
    window.localStorage.setItem(demoStorageKey, JSON.stringify(demoListings));
    return null;
  }

  throw new Error(`Unsupported demo API operation: ${method} ${path}`);
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[character]);
}

function formatDate(value) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric", year: "numeric" }).format(date);
}

function formatEnum(value) {
  return String(value ?? "").toLowerCase().replaceAll("_", " ");
}

function safeExternalUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" || url.protocol === "http:" ? url.href : "";
  } catch {
    return "";
  }
}

function showToast(message, isError = false) {
  const toast = document.createElement("div");
  toast.className = `toast${isError ? " error" : ""}`;
  toast.textContent = message;
  elements.toastRegion.append(toast);
  window.setTimeout(() => toast.remove(), 4500);
}

async function request(path = "", options = {}) {
  if (demoMode) return demoRequest(path, options);

  const response = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      ...(options.body ? { "Content-Type": "application/json" } : {}),
      ...options.headers
    }
  });

  if (!response.ok) {
    let message = `Request failed (${response.status})`;
    try {
      const body = await response.json();
      message = body.detail || body.message || body.error || message;
    } catch {
      if (response.status === 0) message = "Could not connect to the food-waste API.";
    }
    throw new Error(message);
  }

  if (response.status === 204) return null;
  return response.json();
}

function renderStats() {
  const countStatus = (status) => listings.filter((item) => item.status === status).length;
  elements.total.textContent = listings.length;
  elements.pending.textContent = countStatus("PENDING");
  elements.progress.textContent = countStatus("IN_PROCESS");
  elements.distributed.textContent = countStatus("DISTRIBUTED");
  elements.count.textContent = listings.length;
  elements.navCount.textContent = listings.length;
}

function filteredListings() {
  const query = elements.search.value.trim().toLocaleLowerCase();
  const selectedStatus = elements.status.value;
  const selectedCategory = elements.category.value;
  return listings.filter((item) => {
    const matchesSearch = !query || [
      item.description,
      item.category,
      item.quantity,
      item.location
    ].some((value) => String(value ?? "").toLocaleLowerCase().includes(query));
    return matchesSearch
      && (!selectedStatus || item.status === selectedStatus)
      && (!selectedCategory || item.category === selectedCategory);
  });
}

function makeOptions(values, labels, selectedValue) {
  return values.map((value) => {
    const selected = value === selectedValue ? " selected" : "";
    return `<option value="${value}"${selected}>${labels[value]}</option>`;
  }).join("");
}

function renderRow(item) {
  const category = categoryLabels[item.category] || formatEnum(item.category) || "Uncategorized";
  const icon = categoryIcons[item.category] || "✳";
  const image = item.imageUrl
    ? `<img src="${escapeHtml(item.imageUrl)}" alt="" loading="lazy" referrerpolicy="no-referrer">`
    : escapeHtml(icon);
  const safeId = escapeHtml(item.id);
  const statusSelect = makeOptions(statuses, statusLabels, item.status);
  const safetySelect = makeOptions(safetyChecks, safetyLabels, item.safetyCheck);

  return `<tr data-id="${safeId}">
    <td><div class="item-cell"><div class="food-thumb">${image}</div><div class="food-info"><span class="food-name" title="${escapeHtml(item.description)}">${escapeHtml(item.description || "Untitled listing")}</span><span class="food-id">#${safeId}</span></div></div></td>
    <td><span class="category-label">${escapeHtml(category)}</span></td>
    <td><span class="quantity-label">${escapeHtml(item.quantity || "—")}</span><span class="location-label">${escapeHtml(item.location || "Location not set")}</span></td>
    <td class="select-cell"><label class="visually-hidden" for="safety-${safeId}">Safety check for ${escapeHtml(item.description)}</label><select id="safety-${safeId}" data-action="safety">${safetySelect}</select></td>
    <td class="select-cell"><label class="visually-hidden" for="status-${safeId}">Status for ${escapeHtml(item.description)}</label><select id="status-${safeId}" data-action="status">${statusSelect}</select></td>
    <td><span class="date-label">${escapeHtml(formatDate(item.submittedAt))}</span></td>
    <td class="action-cell"><button class="delete-button" type="button" data-action="delete" aria-label="Delete ${escapeHtml(item.description)}" title="Delete listing">×</button></td>
  </tr>`;
}

function renderListings() {
  renderStats();
  const visible = filteredListings();
  elements.rows.innerHTML = visible.map(renderRow).join("");
  elements.empty.hidden = visible.length > 0;
  elements.rows.closest("table").hidden = visible.length === 0;
  if (visible.length === 0 && listings.length > 0) {
    elements.emptyTitle.textContent = "No matching listings";
    elements.emptyCopy.textContent = "Try another search or change the selected filters.";
    document.querySelector("#empty-create").hidden = true;
  } else {
    elements.emptyTitle.textContent = "Nothing on the table yet";
    elements.emptyCopy.textContent = "Add your first food listing to help good food find its next home.";
    document.querySelector("#empty-create").hidden = false;
  }
  elements.summary.textContent = visible.length === listings.length
    ? `Showing ${visible.length} ${visible.length === 1 ? "listing" : "listings"}`
    : `Showing ${visible.length} of ${listings.length} listings`;
}

async function loadListings() {
  elements.rows.innerHTML = '<tr><td class="table-message" colspan="7"><span class="spinner"></span> Loading your food listings…</td></tr>';
  elements.rows.closest("table").hidden = false;
  elements.empty.hidden = true;
  try {
    const data = await request();
    if (!Array.isArray(data)) throw new Error("The food-waste API returned an unexpected response.");
    listings = data;
    renderListings();
  } catch (error) {
    elements.rows.innerHTML = `<tr><td class="table-message" colspan="7">${escapeHtml(error.message)}</td></tr>`;
    elements.empty.hidden = true;
    showToast(error.message, true);
  }
}

function renderOrganizations(organizations) {
  if (organizations.length === 0) {
    elements.organizationList.innerHTML =
      '<div class="directory-placeholder">No named food banks or community centres were found in the public map data for this area.</div>';
    return;
  }

  elements.organizationList.innerHTML = organizations.map((organization) => {
    const latitude = Number(organization.latitude);
    const longitude = Number(organization.longitude);
    const mapUrl = `https://www.openstreetmap.org/?mlat=${encodeURIComponent(latitude)}&mlon=${encodeURIComponent(longitude)}#map=16/${encodeURIComponent(latitude)}/${encodeURIComponent(longitude)}`;
    const website = safeExternalUrl(organization.website);
    const phone = String(organization.phone ?? "").replace(/[^\d+().\-\s]/g, "");
    const contactLinks = [
      website ? `<a href="${escapeHtml(website)}" target="_blank" rel="noreferrer">Website ↗</a>` : "",
      phone ? `<a href="tel:${escapeHtml(phone)}">Call</a>` : ""
    ].filter(Boolean).join("");
    return `<article class="organization-card">
      <div class="organization-type">${escapeHtml(organization.type || "Community organization")}</div>
      <h3>${escapeHtml(organization.name)}</h3>
      <div class="organization-links"><a href="${escapeHtml(mapUrl)}" target="_blank" rel="noreferrer">View on OpenStreetMap ↗</a>${contactLinks}</div>
    </article>`;
  }).join("");
}

async function loadOrganizations() {
  elements.organizationButton.disabled = true;
  elements.organizationButton.textContent = "Searching map…";
  elements.organizationList.innerHTML =
    '<div class="directory-placeholder"><span class="spinner"></span> Looking for public map listings near Jaipur…</div>';
  try {
    const organizations = await request("/organizations");
    if (!Array.isArray(organizations)) {
      throw new Error("The map service returned an unexpected response.");
    }
    renderOrganizations(organizations);
  } catch (error) {
    elements.organizationList.innerHTML =
      `<div class="directory-placeholder directory-error">${escapeHtml(error.message)}</div>`;
    showToast(error.message, true);
  } finally {
    elements.organizationButton.disabled = false;
    elements.organizationButton.innerHTML = 'Find organizations <span aria-hidden="true">↗</span>';
  }
}

function showAiSuggestion(suggestion) {
  elements.aiSuggestion.replaceChildren();
  elements.aiSuggestion.hidden = false;
  const heading = document.createElement("strong");
  heading.className = "suggestion-title";
  heading.textContent = demoMode ? "Demo helper suggestion" : "Suggestion";
  elements.aiSuggestion.append(heading);

  if (suggestion.category || suggestion.quantity) {
    const details = document.createElement("p");
    details.className = "suggestion-details";
    const category = categoryLabels[suggestion.category] || "Category unclear";
    details.textContent = `Category: ${category}${suggestion.quantity ? ` · Quantity: ${suggestion.quantity}` : ""}`;
    elements.aiSuggestion.append(details);
  }

  if (Array.isArray(suggestion.nextSteps) && suggestion.nextSteps.length > 0) {
    const list = document.createElement("ul");
    for (const step of suggestion.nextSteps.slice(0, 3)) {
      const item = document.createElement("li");
      item.textContent = step;
      list.append(item);
    }
    elements.aiSuggestion.append(list);
  }

  const note = document.createElement("p");
  note.className = "suggestion-note";
  note.textContent = suggestion.note;
  elements.aiSuggestion.append(note);

  if (suggestion.category || suggestion.quantity) {
    const apply = document.createElement("button");
    apply.type = "button";
    apply.className = "suggestion-apply";
    apply.textContent = "Apply suggested details";
    apply.addEventListener("click", () => {
      if (categoryLabels[suggestion.category]) {
        elements.form.elements.category.value = suggestion.category;
      }
      if (suggestion.quantity) {
        elements.form.elements.quantity.value = suggestion.quantity;
      }
      showToast("Suggestion applied. Please verify it before saving.");
    });
    elements.aiSuggestion.append(apply);
  }
}

async function requestAiSuggestion() {
  const description = elements.form.elements.description.value.trim();
  if (!description) {
    elements.form.elements.description.focus();
    elements.formError.textContent = "Enter a food description before asking for a suggestion.";
    elements.formError.hidden = false;
    return;
  }

  elements.formError.hidden = true;
  elements.aiSuggest.disabled = true;
  elements.aiSuggest.textContent = "Thinking…";
  try {
    const suggestion = await request("/ai/suggest", {
      method: "POST",
      body: JSON.stringify({
        description,
        quantity: elements.form.elements.quantity.value.trim(),
        category: elements.form.elements.category.value
      })
    });
    showAiSuggestion(suggestion);
  } catch (error) {
    elements.formError.textContent = error.message;
    elements.formError.hidden = false;
  } finally {
    elements.aiSuggest.disabled = false;
    elements.aiSuggest.innerHTML = 'Suggest listing details <span aria-hidden="true">↗</span>';
  }
}

function openDialog() {
  elements.form.reset();
  elements.formError.hidden = true;
  elements.formError.textContent = "";
  elements.aiSuggestion.hidden = true;
  elements.aiSuggestion.replaceChildren();
  elements.dialog.showModal();
  elements.form.querySelector('[name="category"]').focus();
}

function closeDialog() {
  elements.dialog.close();
}

async function createListing(event) {
  event.preventDefault();
  elements.formError.hidden = true;
  const formData = new FormData(elements.form);
  const listing = Object.fromEntries(formData.entries());
  if (!listing.imageUrl) delete listing.imageUrl;
  elements.submit.disabled = true;
  elements.submit.textContent = "Adding listing…";
  try {
    await request("", { method: "POST", body: JSON.stringify(listing) });
    closeDialog();
    showToast("Your food listing has been added.");
    await loadListings();
  } catch (error) {
    elements.formError.textContent = error.message;
    elements.formError.hidden = false;
  } finally {
    elements.submit.disabled = false;
    elements.submit.innerHTML = 'Add listing <span aria-hidden="true">↗</span>';
  }
}

async function updateListing(id, action, value, select) {
  const isStatus = action === "status";
  const path = `/${encodeURIComponent(id)}/${isStatus ? "status" : "safety-check"}`;
  const payload = isStatus ? { status: value } : { safetyCheck: value };
  select.disabled = true;
  try {
    const updated = await request(path, { method: "PUT", body: JSON.stringify(payload) });
    listings = listings.map((item) => item.id === updated.id ? updated : item);
    renderListings();
    showToast(isStatus ? "Listing status updated." : "Food safety check updated.");
  } catch (error) {
    showToast(error.message, true);
    await loadListings();
  } finally {
    const current = document.querySelector(`[data-id="${CSS.escape(String(id))}"] [data-action="${action}"]`);
    if (current) current.disabled = false;
  }
}

async function deleteListing(id, description) {
  if (!window.confirm(`Delete "${description}" from the food listings? This cannot be undone.`)) return;
  try {
    await request(`/${encodeURIComponent(id)}`, { method: "DELETE" });
    listings = listings.filter((item) => String(item.id) !== String(id));
    renderListings();
    showToast("Food listing deleted.");
  } catch (error) {
    showToast(error.message, true);
  }
}

function initialize() {
  if (demoMode) {
    const workspaceMode = document.querySelector("#workspace-mode");
    workspaceMode.textContent = "Local demo";
    workspaceMode.title = "Demo data is saved in this browser, not in the food-waste database.";
    document.querySelector(".ai-tag").textContent = "DEMO";
    document.querySelector(".ai-disclaimer").textContent =
      "Local sample helper only, not a live AI. With the app server configured, listing details are sent to Google Gemini for suggestions. A person must verify details and assess food safety.";
  }
  document.querySelector("#today").textContent = new Intl.DateTimeFormat(undefined, {
    weekday: "short",
    month: "short",
    day: "numeric"
  }).format(new Date());

  document.querySelector("#open-create").addEventListener("click", openDialog);
  document.querySelector("#empty-create").addEventListener("click", openDialog);
  document.querySelectorAll(".close-dialog").forEach((button) => button.addEventListener("click", closeDialog));
  elements.dialog.addEventListener("click", (event) => {
    if (event.target === elements.dialog) closeDialog();
  });
  elements.form.addEventListener("submit", createListing);
  document.querySelector("#refresh-list").addEventListener("click", loadListings);
  elements.aiSuggest.addEventListener("click", requestAiSuggestion);
  elements.organizationButton.addEventListener("click", loadOrganizations);
  elements.search.addEventListener("input", renderListings);
  elements.status.addEventListener("change", renderListings);
  elements.category.addEventListener("change", renderListings);
  elements.rows.addEventListener("change", (event) => {
    const select = event.target.closest("select[data-action]");
    if (select) {
      const row = select.closest("tr");
      const listing = listings.find((item) => String(item.id) === row.dataset.id);
      if (listing) updateListing(listing.id, select.dataset.action, select.value, select);
    }
  });
  elements.rows.addEventListener("click", (event) => {
    const button = event.target.closest('button[data-action="delete"]');
    if (!button) return;
    const row = button.closest("tr");
    const listing = listings.find((item) => String(item.id) === row.dataset.id);
    if (listing) deleteListing(listing.id, listing.description || "Untitled listing");
  });
  document.querySelectorAll(".nav-link").forEach((link) => {
    link.addEventListener("click", () => {
      document.querySelectorAll(".nav-link").forEach((item) => {
        item.classList.remove("active");
        item.removeAttribute("aria-current");
      });
      link.classList.add("active");
      link.setAttribute("aria-current", "page");
    });
  });
  document.addEventListener("keydown", (event) => {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
      event.preventDefault();
      elements.search.focus();
    }
  });

  loadListings();
}

initialize();
