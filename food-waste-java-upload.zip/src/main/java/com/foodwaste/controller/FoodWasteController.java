package com.foodwaste.controller;

import com.foodwaste.controller.dto.CreateFoodWasteRequest;
import com.foodwaste.controller.dto.AiSuggestionRequest;
import com.foodwaste.controller.dto.AiSuggestionResponse;
import com.foodwaste.controller.dto.PublicOrganizationResponse;
import com.foodwaste.controller.dto.SafetyCheckUpdateRequest;
import com.foodwaste.controller.dto.StatusUpdateRequest;
import com.foodwaste.model.FoodWaste;
import com.foodwaste.model.SafetyCheck;
import com.foodwaste.model.WasteStatus;
import com.foodwaste.service.GeminiSuggestionService;
import com.foodwaste.service.PublicOrganizationService;
import com.foodwaste.service.FoodWasteService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/food-waste")
@CrossOrigin(origins = "${app.cors.allowed-origin:http://localhost:8080}")
public class FoodWasteController {
    private final FoodWasteService foodWasteService;
    private final GeminiSuggestionService geminiSuggestionService;
    private final PublicOrganizationService publicOrganizationService;

    public FoodWasteController(
            FoodWasteService foodWasteService,
            GeminiSuggestionService geminiSuggestionService,
            PublicOrganizationService publicOrganizationService) {
        this.foodWasteService = foodWasteService;
        this.geminiSuggestionService = geminiSuggestionService;
        this.publicOrganizationService = publicOrganizationService;
    }

    @GetMapping
    public ResponseEntity<List<FoodWaste>> getAllFoodWaste() {
        return ResponseEntity.ok(foodWasteService.getAllFoodWaste());
    }

    @GetMapping("/{id}")
    public ResponseEntity<FoodWaste> getFoodWasteById(@PathVariable Long id) {
        return ResponseEntity.ok(foodWasteService.getFoodWasteById(id));
    }

    @PostMapping
    public ResponseEntity<FoodWaste> addFoodWaste(
            @Valid @RequestBody CreateFoodWasteRequest request) {
        FoodWaste savedFoodWaste = foodWasteService.saveFoodWaste(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedFoodWaste);
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<FoodWaste> updateStatus(
            @PathVariable Long id,
            @Valid @RequestBody StatusUpdateRequest statusUpdate) {
        FoodWaste updated = foodWasteService.updateFoodWasteStatus(id, statusUpdate.status());
        return ResponseEntity.ok(updated);
    }

    @PutMapping("/{id}/safety-check")
    public ResponseEntity<FoodWaste> updateSafetyCheck(
            @PathVariable Long id,
            @Valid @RequestBody SafetyCheckUpdateRequest safetyUpdate) {
        FoodWaste updated = foodWasteService.updateSafetyCheck(id, safetyUpdate.safetyCheck());
        return ResponseEntity.ok(updated);
    }

    @GetMapping("/category/{category}")
    public ResponseEntity<List<FoodWaste>> getByCategory(@PathVariable String category) {
        return ResponseEntity.ok(foodWasteService.getFoodWasteByCategory(category));
    }

    @GetMapping("/safety-check/{safetyCheck}")
    public ResponseEntity<List<FoodWaste>> getBySafetyCheck(@PathVariable SafetyCheck safetyCheck) {
        return ResponseEntity.ok(foodWasteService.getFoodWasteBySafetyCheck(safetyCheck));
    }

    @GetMapping("/status/pending")
    public ResponseEntity<List<FoodWaste>> getPendingItems() {
        return ResponseEntity.ok(foodWasteService.getFoodWasteByStatus(WasteStatus.PENDING));
    }

    @GetMapping("/organizations")
    public ResponseEntity<List<PublicOrganizationResponse>> getNearbyOrganizations() {
        return ResponseEntity.ok(publicOrganizationService.findInJaipur());
    }

    @PostMapping("/ai/suggest")
    public ResponseEntity<AiSuggestionResponse> suggestListing(
            @Valid @RequestBody AiSuggestionRequest request) {
        return ResponseEntity.ok(geminiSuggestionService.suggest(request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFoodWaste(@PathVariable Long id) {
        foodWasteService.deleteFoodWaste(id);
        return ResponseEntity.noContent().build();
    }
}
