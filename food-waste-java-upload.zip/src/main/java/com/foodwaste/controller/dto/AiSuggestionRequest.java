package com.foodwaste.controller.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record AiSuggestionRequest(
        @NotBlank @Size(max = 500) String description,
        @Size(max = 100) String quantity,
        @Size(max = 40) String category
) {
}
