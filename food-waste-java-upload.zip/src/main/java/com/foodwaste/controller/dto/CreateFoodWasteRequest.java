package com.foodwaste.controller.dto;

import com.foodwaste.model.SafetyCheck;
import com.foodwaste.model.WasteStatus;
import jakarta.validation.constraints.NotBlank;

public record CreateFoodWasteRequest(
        @NotBlank String category,
        @NotBlank String description,
        @NotBlank String quantity,
        @NotBlank String location,
        String imageUrl,
        WasteStatus status,
        SafetyCheck safetyCheck
) {
}
