package com.foodwaste.controller.dto;

import java.util.List;

public record AiSuggestionResponse(
        String category,
        String quantity,
        List<String> nextSteps,
        String note
) {
}
