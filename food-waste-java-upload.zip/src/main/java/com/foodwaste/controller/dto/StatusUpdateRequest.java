package com.foodwaste.controller.dto;

import com.foodwaste.model.WasteStatus;
import jakarta.validation.constraints.NotNull;

public record StatusUpdateRequest(@NotNull WasteStatus status) {
}
