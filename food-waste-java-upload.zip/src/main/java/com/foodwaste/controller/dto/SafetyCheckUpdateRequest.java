package com.foodwaste.controller.dto;

import com.foodwaste.model.SafetyCheck;
import jakarta.validation.constraints.NotNull;

public record SafetyCheckUpdateRequest(@NotNull SafetyCheck safetyCheck) {
}
