package com.foodwaste.controller.dto;

public record PublicOrganizationResponse(
        String id,
        String name,
        String type,
        double latitude,
        double longitude,
        String website,
        String phone
) {
}
