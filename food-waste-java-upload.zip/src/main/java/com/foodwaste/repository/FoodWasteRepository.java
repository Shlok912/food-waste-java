package com.foodwaste.repository;

import com.foodwaste.model.FoodWaste;
import com.foodwaste.model.SafetyCheck;
import com.foodwaste.model.WasteStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FoodWasteRepository extends JpaRepository<FoodWaste, Long> {
    List<FoodWaste> findByStatus(WasteStatus status);

    List<FoodWaste> findBySafetyCheck(SafetyCheck safetyCheck);

    List<FoodWaste> findByCategory(String category);
}
