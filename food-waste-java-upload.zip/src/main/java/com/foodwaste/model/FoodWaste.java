package com.foodwaste.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "food_waste")
public class FoodWaste {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(nullable = false)
    private String category;

    @NotBlank
    @Column(nullable = false)
    private String description;

    @NotBlank
    @Column(nullable = false)
    private String quantity;

    @NotBlank
    @Column(nullable = false)
    private String location;

    private String imageUrl;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private WasteStatus status = WasteStatus.PENDING;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private SafetyCheck safetyCheck = SafetyCheck.PENDING;

    private LocalDateTime submittedAt;
    private LocalDateTime processedAt;

    @PrePersist
    void setDefaults() {
        if (status == null) {
            status = WasteStatus.PENDING;
        }
        if (safetyCheck == null) {
            safetyCheck = SafetyCheck.PENDING;
        }
        if (submittedAt == null) {
            submittedAt = LocalDateTime.now();
        }
    }
}
