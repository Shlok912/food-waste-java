package com.foodwaste.model;

public enum SafetyCheck {
    PENDING,
    SAFE,
    UNSAFE,
    UNDER_REVIEW
}
