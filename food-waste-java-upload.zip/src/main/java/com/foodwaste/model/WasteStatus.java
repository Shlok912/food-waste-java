package com.foodwaste.model;

public enum WasteStatus {
    PENDING,
    IN_PROCESS,
    COMPLETED,
    DISTRIBUTED
}
