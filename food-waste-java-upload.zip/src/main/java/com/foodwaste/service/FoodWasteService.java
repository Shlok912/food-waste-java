package com.foodwaste.service;

import com.foodwaste.controller.dto.CreateFoodWasteRequest;
import com.foodwaste.model.FoodWaste;
import com.foodwaste.model.SafetyCheck;
import com.foodwaste.model.WasteStatus;
import com.foodwaste.repository.FoodWasteRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class FoodWasteService {
    private final FoodWasteRepository foodWasteRepository;

    public FoodWasteService(FoodWasteRepository foodWasteRepository) {
        this.foodWasteRepository = foodWasteRepository;
    }

    public FoodWaste saveFoodWaste(CreateFoodWasteRequest request) {
        FoodWaste foodWaste = new FoodWaste();
        foodWaste.setCategory(request.category());
        foodWaste.setDescription(request.description());
        foodWaste.setQuantity(request.quantity());
        foodWaste.setLocation(request.location());
        foodWaste.setImageUrl(request.imageUrl());
        foodWaste.setStatus(request.status() == null ? WasteStatus.PENDING : request.status());
        foodWaste.setSafetyCheck(
                request.safetyCheck() == null ? SafetyCheck.PENDING : request.safetyCheck());
        foodWaste.setSubmittedAt(LocalDateTime.now());
        return foodWasteRepository.save(foodWaste);
    }

    @Transactional(readOnly = true)
    public List<FoodWaste> getAllFoodWaste() {
        return foodWasteRepository.findAll();
    }

    @Transactional(readOnly = true)
    public FoodWaste getFoodWasteById(Long id) {
        return findFoodWaste(id);
    }

    @Transactional(readOnly = true)
    public List<FoodWaste> getFoodWasteByStatus(WasteStatus status) {
        return foodWasteRepository.findByStatus(status);
    }

    @Transactional(readOnly = true)
    public List<FoodWaste> getFoodWasteBySafetyCheck(SafetyCheck safetyCheck) {
        return foodWasteRepository.findBySafetyCheck(safetyCheck);
    }

    public FoodWaste updateFoodWasteStatus(Long id, WasteStatus status) {
        FoodWaste foodWaste = findFoodWaste(id);
        foodWaste.setStatus(status);
        foodWaste.setProcessedAt(
                status == WasteStatus.COMPLETED || status == WasteStatus.DISTRIBUTED
                        ? LocalDateTime.now()
                        : null);
        return foodWasteRepository.save(foodWaste);
    }

    public FoodWaste updateSafetyCheck(Long id, SafetyCheck safetyCheck) {
        FoodWaste foodWaste = findFoodWaste(id);
        foodWaste.setSafetyCheck(safetyCheck);
        return foodWasteRepository.save(foodWaste);
    }

    @Transactional(readOnly = true)
    public List<FoodWaste> getFoodWasteByCategory(String category) {
        return foodWasteRepository.findByCategory(category);
    }

    public void deleteFoodWaste(Long id) {
        foodWasteRepository.delete(findFoodWaste(id));
    }

    private FoodWaste findFoodWaste(Long id) {
        return foodWasteRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Food waste item " + id + " was not found"));
    }
}
