package com.foodwaste.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.foodwaste.controller.dto.PublicOrganizationResponse;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Service
public class PublicOrganizationService {
    private static final String OVERPASS_URL = "https://overpass-api.de/api/interpreter";
    private static final double JAIPUR_LATITUDE = 26.9124;
    private static final double JAIPUR_LONGITUDE = 75.7873;
    private static final int SEARCH_RADIUS_METERS = 20_000;

    private final RestTemplate restTemplate;
    private List<PublicOrganizationResponse> cachedOrganizations;
    private Instant cacheExpiresAt;

    public PublicOrganizationService(RestTemplateBuilder restTemplateBuilder) {
        this.restTemplate = restTemplateBuilder
                .setConnectTimeout(Duration.ofSeconds(5))
                .setReadTimeout(Duration.ofSeconds(25))
                .build();
    }

    public synchronized List<PublicOrganizationResponse> findInJaipur() {
        if (cachedOrganizations != null && Instant.now().isBefore(cacheExpiresAt)) {
            return cachedOrganizations;
        }

        String query = String.format(Locale.ROOT, """
                [out:json][timeout:20];
                (
                  nwr["social_facility"="food_bank"](around:%d,%.4f,%.4f);
                  nwr["amenity"="food_bank"](around:%d,%.4f,%.4f);
                  nwr["amenity"="community_centre"](around:%d,%.4f,%.4f);
                );
                out center tags;
                """,
                SEARCH_RADIUS_METERS, JAIPUR_LATITUDE, JAIPUR_LONGITUDE,
                SEARCH_RADIUS_METERS, JAIPUR_LATITUDE, JAIPUR_LONGITUDE,
                SEARCH_RADIUS_METERS, JAIPUR_LATITUDE, JAIPUR_LONGITUDE);

        MultiValueMap<String, String> form = new LinkedMultiValueMap<>();
        form.add("data", query);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.set("User-Agent", "HarvestFoodRecovery/0.1");

        JsonNode response;
        try {
            response = restTemplate.postForObject(
                    OVERPASS_URL, new HttpEntity<>(form, headers), JsonNode.class);
        } catch (RestClientException exception) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_GATEWAY,
                    "The public map service is temporarily unavailable. Please try again later.");
        }

        if (response == null || !response.path("elements").isArray()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_GATEWAY,
                    "The public map service returned an invalid response.");
        }

        List<PublicOrganizationResponse> organizations = new ArrayList<>();
        for (JsonNode element : response.path("elements")) {
            JsonNode tags = element.path("tags");
            String name = text(tags, "name:en", text(tags, "name", ""));
            if (name.isBlank()) {
                continue;
            }

            JsonNode coordinates = element.has("center") ? element.path("center") : element;
            double latitude = coordinates.path("lat").asDouble(Double.NaN);
            double longitude = coordinates.path("lon").asDouble(Double.NaN);
            if (!Double.isFinite(latitude) || !Double.isFinite(longitude)) {
                continue;
            }

            String type = "social_facility".equals(text(tags, "social_facility", ""))
                    ? "Food bank"
                    : "Food bank".equalsIgnoreCase(text(tags, "amenity", ""))
                            ? "Food bank"
                            : "Community centre";
            String elementType = text(element, "type", "place");
            String elementId = text(element, "id", "");
            organizations.add(new PublicOrganizationResponse(
                    elementType + "-" + elementId,
                    name,
                    type,
                    latitude,
                    longitude,
                    text(tags, "website", ""),
                    text(tags, "phone", "")));
        }
        cachedOrganizations = List.copyOf(organizations);
        cacheExpiresAt = Instant.now().plus(Duration.ofMinutes(15));
        return cachedOrganizations;
    }

    private static String text(JsonNode node, String field, String fallback) {
        JsonNode value = node.path(field);
        return value.isMissingNode() || value.isNull() ? fallback : value.asText(fallback);
    }
}
